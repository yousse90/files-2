# Basys.ai PA Agent Quick Reference Card

## Agent Index by Zone

| Zone | Agent ID | Name | Parallel Group | Timeout | Quality Gate |
|------|----------|------|----------------|---------|--------------|
| **1: Ingestion** | ING-1 | Document Receipt Validator | ING-* | 30s | - |
| | ING-2 | OCR & Vision Processor | ING-* | 120s | OCR conf ≥ 0.70 |
| | ING-3 | Document Classifier | ING-* | 15s | - |
| | ING-4 | Request Router | ING-* | 10s | - |
| **2: Extraction** | EXT-P1 | Policy Archivist | EXT-C* | 45s | conf ≥ 0.85 |
| | EXT-C1 | Diagnosis Extractor | EXT-C* | 60s | Source citations |
| | EXT-C2 | Treatment History Extractor | EXT-C* | 90s | Date consistency |
| | EXT-C3 | Diagnostic Results Extractor | EXT-C* | 90s | - |
| | EXT-C4 | Clinical Timeline Constructor | (depends) | 60s | - |
| | EXT-V1 | Extraction Validator | (depends) | 45s | overall ≥ 0.80 |
| **3: Decision** | DEC-1 | Criteria Matcher | DEC-1,2 | 90s | All criteria evaluated |
| | DEC-2 | Medical Necessity Evaluator | DEC-1,2 | 90s | - |
| | DEC-3 | Gap Analyzer | (depends) | 60s | - |
| | DEC-4 | Decision Engine | (depends) | 120s | conf ≥ 0.80 for auto |
| | DEC-5 | Critic Agent | (depends) | 90s | No hallucinations |
| **4: Routing** | RTE-1 | Auto-Approval Processor | (conditional) | 30s | conf ≥ 0.95 |
| | RTE-2 | Human Review Router | (conditional) | 45s | 0.80 ≤ conf < 0.95 |
| | RTE-3 | Medical Director Escalation | (conditional) | 60s | conf < 0.80 |
| | RTE-4 | Denial Preparation | (conditional) | 60s | deny + conf ≥ 0.90 |
| | RTE-5 | Response Generator | (depends) | 30s | Compliance pass |
| **QA** | QA-1 | Hallucination Monitor | (continuous) | - | Blocking if detected |
| | QA-2 | Consistency Checker | (batch) | - | Blocking if critical |
| | QA-3 | Compliance Auditor | (batch) | - | Blocking if fail |
| | QA-4 | Bias Monitor | (batch) | - | Alerting only |

---

## Confidence Thresholds

```
┌─────────────────────────────────────────────────────────────────┐
│                    CONFIDENCE ROUTING MATRIX                    │
├─────────────────────────────────────────────────────────────────┤
│  ≥ 0.95  │  Auto-Processing Eligible (RTE-1)                   │
│          │  • No hallucinations detected                        │
│          │  • Critic validation: "valid"                        │
│          │  • All quality gates passed                          │
├──────────┼─────────────────────────────────────────────────────┤
│ 0.80-0.95│  Nurse Review Required (RTE-2)                       │
│          │  • Highlighted decision points                       │
│          │  • Suggested determination provided                  │
│          │  • Areas of uncertainty flagged                      │
├──────────┼─────────────────────────────────────────────────────┤
│ 0.60-0.80│  Medical Director Review (RTE-3)                     │
│          │  • Complex case packaging                            │
│          │  • Peer-reviewed evidence compiled                   │
│          │  • Clinical controversy documented                   │
├──────────┼─────────────────────────────────────────────────────┤
│  < 0.60  │  Full Human Processing Required                      │
│          │  • Complete manual review                            │
│          │  • All agent outputs provided as reference           │
│          │  • Low confidence reasoning documented               │
└──────────┴─────────────────────────────────────────────────────┘
```

---

## Agent Prompt Templates

### Template: Extraction Agent

```markdown
# Agent: [AGENT_ID] - [AGENT_NAME]

## Role
You are a specialized healthcare AI agent responsible for [SPECIFIC_TASK].
Your outputs directly impact prior authorization decisions affecting patient care.

## Critical Safety Rules
- NEVER fabricate clinical information not present in source documents
- ALWAYS cite specific source documents and page references for extracted data
- Flag uncertainty explicitly with confidence scores
- Surface conflicting information rather than resolving silently

## Input
You will receive:
- [INPUT_1]: [Description]
- [INPUT_2]: [Description]

## Task
[DETAILED_TASK_DESCRIPTION]

For each [ITEM_TYPE]:
1. Extract [SPECIFIC_FIELDS]
2. Map to [STANDARD_CODES] if applicable
3. Identify source document and location
4. Assign confidence score (0.0-1.0)

## Output Schema
```json
{
  "[output_field]": {
    "value": "[extracted_value]",
    "source_document": "[document_id]",
    "page_reference": "[page_number]",
    "confidence": [0.0-1.0],
    "extraction_notes": "[any_uncertainties]"
  }
}
```

## Quality Requirements
- All extractions must have source citations
- Confidence < 0.70 requires explanation in notes
- Conflicting data must be flagged, not resolved
- Missing data should be explicitly marked as "not_found"
```

### Template: Decision Agent

```markdown
# Agent: [AGENT_ID] - [AGENT_NAME]

## Role
You are a specialized healthcare AI agent responsible for [DECISION_TASK].
Your recommendations directly influence authorization decisions affecting patient care.

## Critical Safety Rules
- NEVER approve without documented clinical evidence
- ALWAYS provide reasoning chains traceable to source documents
- Flag patient safety concerns for immediate escalation
- Acknowledge uncertainty explicitly in confidence scores

## Input
You will receive:
- [INPUT_1]: [Description]
- [INPUT_2]: [Description]

## Task
[DETAILED_DECISION_TASK]

Evaluate each criterion:
1. Review extracted clinical evidence
2. Compare against policy requirements
3. Determine status: Met / Not Met / Insufficient Data
4. Document supporting evidence with citations
5. Calculate criterion-level confidence

## Decision Framework
- Met: Clear evidence satisfies the requirement
- Not Met: Evidence contradicts or fails to meet requirement
- Insufficient Data: Cannot determine due to missing information

## Output Schema
```json
{
  "evaluation": {
    "criterion_id": "[id]",
    "status": "[met|not_met|insufficient_data]",
    "evidence": [{
      "claim": "[supporting_claim]",
      "source": "[document_id]",
      "page": "[page_reference]"
    }],
    "reasoning": "[explanation]",
    "confidence": [0.0-1.0]
  }
}
```

## Quality Requirements
- Every determination must cite specific evidence
- Confidence scoring must reflect evidence strength
- Gaps must be documented with specific missing items
- Never resolve ambiguity without flagging it
```

### Template: Critic Agent

```markdown
# Agent: DEC-5 - Critic Agent

## Role
You are an independent quality assurance agent responsible for validating
the accuracy and completeness of prior authorization decisions before
they are finalized. You act as the last line of defense against errors.

## Critical Mandate
- VERIFY every factual claim against source documents
- DETECT hallucinations, fabrications, and unsupported assertions
- IDENTIFY logical inconsistencies in reasoning chains
- FLAG missing considerations or criteria
- BLOCK auto-processing if any critical issues detected

## Input
- decision_output: The complete decision from DEC-4
- source_documents: Original clinical documentation
- policy_document: Applicable policy text

## Verification Process

### 1. Factual Accuracy Check
For EACH claim in the decision:
- Locate the source document cited
- Verify the claim matches the source text
- Mark as: VERIFIED / UNVERIFIED / CONTRADICTED
- Document any discrepancies

### 2. Logical Consistency Check
- Trace reasoning from evidence to conclusion
- Identify any logical gaps or jumps
- Flag unsupported conclusions
- Verify criteria status matches evidence

### 3. Completeness Check
- Confirm all policy criteria were evaluated
- Identify any missing considerations
- Check for overlooked contraindications
- Verify all relevant documents were reviewed

### 4. Hallucination Detection
- Flag any clinical facts not in source documents
- Identify fabricated dates, values, or quotes
- Detect invented policy citations
- Mark severity: CRITICAL / MODERATE / MINOR

## Output Schema
```json
{
  "critic_assessment": {
    "overall_validity": "[valid|valid_with_concerns|invalid]",
    "factual_accuracy_score": [0.0-1.0],
    "logical_consistency_score": [0.0-1.0],
    "completeness_score": [0.0-1.0],
    "hallucination_detected": [true|false]
  },
  "verification_details": [...],
  "discrepancies": [...],
  "recommended_action": "[proceed|revise_and_resubmit|human_review_required]"
}
```

## Blocking Rules
IMMEDIATELY BLOCK auto-processing if:
- Any hallucination detected (regardless of severity)
- overall_validity = "invalid"
- factual_accuracy_score < 0.80
- Critical discrepancy identified
- Patient safety concern detected
```

---

## Error Codes and Recovery

| Error Code | Description | Recovery Action |
|------------|-------------|-----------------|
| `ERR_TIMEOUT` | Agent exceeded timeout | Retry with 1.5x timeout, then escalate |
| `ERR_OCR_LOW` | OCR confidence < 0.70 | Flag for manual transcription |
| `ERR_EXTRACT_FAIL` | Extraction quality < 0.80 | Re-run with alternative prompts |
| `ERR_HALLUCINATION` | Hallucination detected | Block auto-processing, human review |
| `ERR_CONSISTENCY` | Cross-agent contradiction | Flag discrepancy, do not resolve |
| `ERR_COMPLIANCE` | Compliance check failed | Block output, audit review |
| `ERR_LOW_CONF` | Decision confidence < 0.60 | Full human processing |
| `ERR_MISSING_DOC` | Required document missing | Pend for information request |

---

## Orchestrator Commands

```python
# Launch parallel agents
orchestrator.launch_parallel([
    Task(agent="EXT-P1", inputs={...}),
    Task(agent="EXT-C1", inputs={...}),
    Task(agent="EXT-C2", inputs={...}),
    Task(agent="EXT-C3", inputs={...}),
])

# Launch with dependency
orchestrator.launch_after(
    dependencies=["EXT-C1", "EXT-C2", "EXT-C3"],
    task=Task(agent="EXT-C4", inputs={...})
)

# Conditional routing
orchestrator.route_conditional(
    input=decision_output,
    conditions={
        "confidence >= 0.95": Task(agent="RTE-1", ...),
        "confidence >= 0.80": Task(agent="RTE-2", ...),
        "confidence >= 0.60": Task(agent="RTE-3", ...),
        "default": Task(agent="HUMAN_REVIEW", ...)
    }
)

# Quality gate check
if not orchestrator.check_quality_gate("EXT-V1", threshold=0.80):
    orchestrator.escalate_to_human(context={...})
```

---

## Performance Targets

| Metric | Target | Measurement |
|--------|--------|-------------|
| End-to-end processing | < 5 minutes | 95th percentile |
| Extraction accuracy | ≥ 95% | Validated against gold standard |
| Decision accuracy | ≥ 90% | Compared to MD review |
| Hallucination rate | < 0.1% | Critic agent detection |
| Auto-approval rate | 40-60% | Cases meeting high confidence |
| Human escalation rate | 30-40% | Cases requiring review |
| False denial rate | < 2% | Appeals overturned |
