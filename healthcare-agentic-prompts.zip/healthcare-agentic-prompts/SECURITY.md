# Security Policy

## 🛡️ Healthcare Data Security

This repository deals with healthcare AI systems that may process Protected Health Information (PHI). Security is paramount.

## ⚠️ Critical Rules

### NO PHI IN THIS REPOSITORY

**Absolutely NO real patient data may be committed to this repository.**

This includes:
- Patient names, dates of birth, addresses
- Medical record numbers
- Social Security numbers
- Insurance information
- Any other HIPAA-protected identifiers
- Real clinical notes or medical records
- Actual authorization decisions

### Synthetic Data Only

All examples, test cases, and documentation must use:
- Completely synthetic/fictional patient data
- Clearly labeled as "SYNTHETIC" or "EXAMPLE"
- Data that cannot be traced to real individuals

## 🔐 Prompt Security Considerations

When contributing prompts, consider:

### Prompt Injection Prevention
- Prompts should be robust against injection attacks
- Include input sanitization guidance
- Document any known vulnerabilities

### Data Exfiltration Prevention
- Prompts should not leak sensitive system information
- Avoid patterns that could expose training data
- Include output filtering recommendations

### Jailbreak Resistance
- Healthcare prompts must resist attempts to bypass safety guardrails
- Document tested attack vectors
- Include recommended defenses

## 📢 Reporting Security Issues

### For Prompt Vulnerabilities

If you discover a security vulnerability in a prompt (e.g., prompt injection susceptibility, safety bypass):

1. **DO NOT** open a public issue
2. Email: [security@yourdomain.com]
3. Include:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

### For PHI Exposure

If you discover any real PHI has been committed to this repository:

1. **IMMEDIATELY** email: [security@yourdomain.com]
2. Include the file path and commit hash
3. We will remove it within 24 hours and notify affected parties

## 🔄 Security Review Process

All contributions undergo security review:

| Check | Description |
|-------|-------------|
| PHI Scan | Automated scan for potential PHI patterns |
| Prompt Injection | Manual review for injection vulnerabilities |
| Safety Bypass | Testing for safety guardrail circumvention |
| Data Leakage | Review for unintended information disclosure |

## 📋 Security Checklist for Contributors

Before submitting a PR, verify:

- [ ] No real PHI in any files
- [ ] All examples use synthetic data
- [ ] Synthetic data is clearly labeled
- [ ] Prompts include input validation guidance
- [ ] Safety guardrails cannot be easily bypassed
- [ ] No sensitive system information exposed
- [ ] Test cases use only fictional scenarios

## 🏥 HIPAA Considerations

If you are implementing these prompts in a production healthcare system:

1. **This repository does not provide HIPAA compliance**
2. You are responsible for:
   - Business Associate Agreements (BAAs)
   - Access controls and audit logging
   - Encryption in transit and at rest
   - Proper data handling procedures
   - Staff training on PHI handling

## 📚 Resources

- [HIPAA Security Rule](https://www.hhs.gov/hipaa/for-professionals/security/index.html)
- [OWASP LLM Top 10](https://owasp.org/www-project-top-10-for-large-language-model-applications/)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)

## 📬 Contact

Security issues: [security@yourdomain.com]
General questions: [your.email@example.com]

---

**Remember: Patient safety and data security are non-negotiable.**
