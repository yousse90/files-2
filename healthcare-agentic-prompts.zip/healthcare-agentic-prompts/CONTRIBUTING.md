# Contributing to Healthcare Agentic Prompts

Thank you for your interest in contributing to this repository! This document provides guidelines for contributions.

## 🎯 Our Mission

To create a comprehensive, open-source collection of safe, effective prompt engineering patterns for healthcare AI systems that prioritize patient safety and clinical accuracy.

## 📋 Types of Contributions

### 1. New Agent Prompts

We welcome new agent prompts for:
- Additional medical specialties (cardiology, oncology, neurology, etc.)
- Different healthcare workflows (appeals, peer-to-peer, utilization review)
- Alternative extraction patterns (different document types)
- International healthcare systems (non-US regulatory frameworks)

### 2. Improvements to Existing Prompts

- Enhanced safety guardrails
- Better error handling
- Improved output schemas
- Performance optimizations
- Bug fixes

### 3. Test Cases and Benchmarks

- Synthetic test cases (no real PHI)
- Evaluation methodologies
- Benchmark datasets
- Quality metrics

### 4. Documentation

- Usage examples
- Integration guides
- Architecture documentation
- Translations

## 📝 Contribution Process

### Step 1: Open an Issue

Before starting work, open an issue to discuss your proposed contribution:

```markdown
**Type**: [New Agent / Improvement / Test Case / Documentation]

**Description**: 
Brief description of what you want to contribute.

**Use Case**:
What problem does this solve? Who benefits?

**Safety Considerations**:
Any patient safety or compliance implications?
```

### Step 2: Fork and Branch

```bash
# Fork the repository on GitHub, then:
git clone https://github.com/YOUR_USERNAME/healthcare-agentic-prompts.git
cd healthcare-agentic-prompts
git checkout -b feature/your-feature-name
```

### Step 3: Follow the Templates

#### For New Agent Prompts

Use the standard agent template:

```markdown
# Agent: [AGENT_ID] - [Agent Name]

## Overview
Brief description of what this agent does.

## Role
```
You are a specialized healthcare AI agent responsible for [TASK].
Your outputs directly impact [IMPACT_AREA] affecting patient care.
```

## Critical Safety Rules
- NEVER [prohibited action]
- ALWAYS [required action]
- [Additional safety rules]

## Input Schema
```yaml
inputs:
  - name: input_name
    type: string
    description: What this input contains
    required: true
```

## Output Schema
```json
{
  "output_field": {
    "type": "string",
    "description": "What this output contains"
  }
}
```

## Quality Requirements
- [Requirement 1]
- [Requirement 2]

## Example Usage
[Provide a concrete example]

## Test Cases
[Link to test cases or include inline]
```

#### For Prompt Patterns

```markdown
# Pattern: [Pattern Name]

## Problem
What problem does this pattern solve?

## Solution
How does the pattern address the problem?

## Structure
```
[Pattern structure/template]
```

## When to Use
- [Scenario 1]
- [Scenario 2]

## When NOT to Use
- [Anti-pattern scenario]

## Healthcare Considerations
Special considerations for healthcare use.

## Example
Complete working example.
```

### Step 4: Test Your Contribution

Before submitting:

1. **Validate JSON schemas** are syntactically correct
2. **Test with sample inputs** (synthetic data only)
3. **Check for safety issues**:
   - Does it prevent hallucinations?
   - Does it require source citations?
   - Does it handle uncertainty appropriately?
4. **Verify documentation** is complete

### Step 5: Submit Pull Request

```markdown
## Description
[What does this PR add/change?]

## Type of Change
- [ ] New agent prompt
- [ ] Improvement to existing prompt
- [ ] Test cases
- [ ] Documentation
- [ ] Bug fix

## Safety Review
- [ ] Includes hallucination prevention
- [ ] Requires source citations
- [ ] Handles uncertainty appropriately
- [ ] Includes human escalation triggers
- [ ] No real PHI in examples

## Testing
- [ ] Tested with synthetic data
- [ ] JSON schemas validated
- [ ] Example outputs verified

## Documentation
- [ ] README updated (if needed)
- [ ] Inline documentation complete
- [ ] Examples provided
```

## 🛡️ Safety Requirements

All contributions MUST adhere to these safety principles:

### Mandatory Elements

1. **Hallucination Prevention**
   ```markdown
   - NEVER fabricate clinical information not in source documents
   - ALWAYS cite specific sources for clinical claims
   ```

2. **Uncertainty Handling**
   ```markdown
   - Flag uncertainty explicitly with confidence scores
   - Route low-confidence outputs to human review
   ```

3. **Human Escalation**
   ```markdown
   - Define clear escalation triggers
   - Never auto-approve without high confidence
   ```

4. **Audit Trail**
   ```markdown
   - All outputs must be traceable to inputs
   - Preserve reasoning chains for review
   ```

### Prohibited Elements

- ❌ Real patient health information (PHI)
- ❌ Prompts that auto-approve without safety checks
- ❌ Prompts that hide uncertainty
- ❌ Prompts that fabricate clinical evidence
- ❌ Prompts that bypass human review for edge cases

## 📁 File Naming Conventions

```
agents/
  extraction/
    [specialty]-[function].md      # e.g., cardiology-history-extractor.md
  decision/
    [function]-[type].md           # e.g., criteria-matcher-msk.md
  
patterns/
  [category]/
    [pattern-name].md              # e.g., chain-patterns/parallel-workers.md

evaluation/
  test-cases/
    [agent-id]-tests.json          # e.g., ext-c1-tests.json
```

## 🔍 Code Review Criteria

PRs will be reviewed for:

| Criterion | Weight | Description |
|-----------|--------|-------------|
| **Safety** | Critical | Must meet all safety requirements |
| **Accuracy** | High | Clinically sound and factually correct |
| **Completeness** | High | Full documentation and schemas |
| **Usability** | Medium | Clear, well-organized, easy to use |
| **Performance** | Medium | Efficient, avoids unnecessary complexity |

## 🏷️ Labels

We use these labels for issues and PRs:

| Label | Description |
|-------|-------------|
| `safety-critical` | Related to patient safety |
| `new-agent` | New agent prompt |
| `enhancement` | Improvement to existing content |
| `documentation` | Documentation only |
| `test-cases` | Test cases or benchmarks |
| `good-first-issue` | Good for newcomers |
| `help-wanted` | Extra attention needed |

## 📜 Code of Conduct

By participating in this project, you agree to abide by our [Code of Conduct](CODE_OF_CONDUCT.md).

### Key Points

- Be respectful and inclusive
- Prioritize patient safety in all discussions
- Acknowledge that healthcare AI is high-stakes
- Welcome constructive criticism
- Focus on the work, not the person

## ❓ Questions?

- Open a [Discussion](https://github.com/YOUR_USERNAME/healthcare-agentic-prompts/discussions) for general questions
- Open an [Issue](https://github.com/YOUR_USERNAME/healthcare-agentic-prompts/issues) for bugs or feature requests
- Email [your.email@example.com] for sensitive matters

---

Thank you for contributing to safer healthcare AI! 🏥
