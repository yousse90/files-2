# Basys.ai Prior Authorization Multi-Agent Architecture

## System Overview Diagram

```mermaid
flowchart TB
    subgraph ORCHESTRATOR["🎯 PA ORCHESTRATOR AGENT"]
        direction TB
        ORC[/"Delegation Controller<br/>• Task Distribution<br/>• Dependency Management<br/>• Quality Gates"/]
    end

    subgraph ZONE1["ZONE 1: INGESTION"]
        direction LR
        ING1["ING-1<br/>Document<br/>Validator"]
        ING2["ING-2<br/>OCR/Vision<br/>Processor"]
        ING3["ING-3<br/>Document<br/>Classifier"]
        ING4["ING-4<br/>Request<br/>Router"]
    end

    subgraph ZONE2["ZONE 2: EXTRACTION"]
        direction TB
        subgraph PARALLEL_EXT["Parallel Extraction"]
            direction LR
            EXTP1["EXT-P1<br/>Policy<br/>Archivist"]
            EXTC1["EXT-C1<br/>Diagnosis<br/>Extractor"]
            EXTC2["EXT-C2<br/>Treatment<br/>History"]
            EXTC3["EXT-C3<br/>Diagnostic<br/>Results"]
            EXTC4["EXT-C4<br/>Timeline<br/>Constructor"]
        end
        EXTV1["EXT-V1<br/>Extraction<br/>Validator"]
    end

    subgraph ZONE3["ZONE 3: DECISION-MAKING"]
        direction TB
        subgraph PARALLEL_DEC["Parallel Decision"]
            direction LR
            DEC1["DEC-1<br/>Criteria<br/>Matcher"]
            DEC2["DEC-2<br/>Medical<br/>Necessity"]
        end
        DEC3["DEC-3<br/>Gap<br/>Analyzer"]
        DEC4["DEC-4<br/>Decision<br/>Engine"]
        DEC5["DEC-5<br/>Critic<br/>Agent"]
    end

    subgraph ZONE4["ZONE 4: ROUTING"]
        direction LR
        RTE1["RTE-1<br/>Auto<br/>Approval"]
        RTE2["RTE-2<br/>Nurse<br/>Review"]
        RTE3["RTE-3<br/>MD<br/>Escalation"]
        RTE4["RTE-4<br/>Denial<br/>Prep"]
        RTE5["RTE-5<br/>Response<br/>Generator"]
    end

    subgraph QA["CONTINUOUS QA"]
        direction LR
        QA1["QA-1<br/>Hallucination<br/>Monitor"]
        QA2["QA-2<br/>Consistency<br/>Checker"]
        QA3["QA-3<br/>Compliance<br/>Auditor"]
        QA4["QA-4<br/>Bias<br/>Monitor"]
    end

    %% Flow connections
    ORC --> ZONE1
    ZONE1 --> ZONE2
    ZONE2 --> ZONE3
    ZONE3 --> ZONE4

    %% Zone 1 parallel
    ING1 -.-> ING2 & ING3 & ING4

    %% Zone 2 flow
    EXTP1 & EXTC1 & EXTC2 & EXTC3 --> EXTC4
    EXTC4 --> EXTV1

    %% Zone 3 flow
    DEC1 & DEC2 --> DEC3
    DEC3 --> DEC4
    DEC4 --> DEC5

    %% Zone 4 conditional routing
    DEC5 -->|"conf ≥ 0.95"| RTE1
    DEC5 -->|"0.80 ≤ conf < 0.95"| RTE2
    DEC5 -->|"conf < 0.80"| RTE3
    DEC5 -->|"deny + conf ≥ 0.90"| RTE4
    RTE1 & RTE2 & RTE3 & RTE4 --> RTE5

    %% QA monitoring
    QA -.->|"Continuous Monitoring"| ZONE2 & ZONE3 & ZONE4

    %% Styling
    classDef orchestrator fill:#1a1a2e,stroke:#e94560,stroke-width:3px,color:#fff
    classDef zone1 fill:#16213e,stroke:#0f3460,stroke-width:2px,color:#fff
    classDef zone2 fill:#0f3460,stroke:#e94560,stroke-width:2px,color:#fff
    classDef zone3 fill:#533483,stroke:#e94560,stroke-width:2px,color:#fff
    classDef zone4 fill:#1a1a2e,stroke:#0f3460,stroke-width:2px,color:#fff
    classDef qa fill:#e94560,stroke:#fff,stroke-width:2px,color:#fff

    class ORC orchestrator
    class ING1,ING2,ING3,ING4 zone1
    class EXTP1,EXTC1,EXTC2,EXTC3,EXTC4,EXTV1 zone2
    class DEC1,DEC2,DEC3,DEC4,DEC5 zone3
    class RTE1,RTE2,RTE3,RTE4,RTE5 zone4
    class QA1,QA2,QA3,QA4 qa
```

## Agent Dependency Graph

```mermaid
flowchart LR
    subgraph PHASE1["Phase 1: Ingestion<br/>(Parallel)"]
        ING1["ING-1"] & ING2["ING-2"] & ING3["ING-3"] & ING4["ING-4"]
    end

    subgraph PHASE2["Phase 2: Extraction<br/>(Parallel + Sequential)"]
        EXTP1["EXT-P1<br/>Policy"] & EXTC1["EXT-C1<br/>Diagnosis"] & EXTC2["EXT-C2<br/>Treatment"] & EXTC3["EXT-C3<br/>Diagnostics"]
        EXTC4["EXT-C4<br/>Timeline"]
        EXTV1["EXT-V1<br/>Validator"]
    end

    subgraph PHASE3["Phase 3: Decision<br/>(Parallel + Sequential)"]
        DEC1["DEC-1<br/>Matcher"] & DEC2["DEC-2<br/>Necessity"]
        DEC3["DEC-3<br/>Gaps"]
        DEC4["DEC-4<br/>Engine"]
        DEC5["DEC-5<br/>Critic"]
    end

    subgraph PHASE4["Phase 4: Routing<br/>(Conditional)"]
        RTE["RTE-1/2/3/4"]
        RTE5["RTE-5<br/>Response"]
    end

    PHASE1 --> EXTP1 & EXTC1 & EXTC2 & EXTC3
    EXTC1 & EXTC2 & EXTC3 --> EXTC4
    EXTP1 & EXTC4 --> EXTV1
    EXTV1 --> DEC1 & DEC2
    DEC1 & DEC2 --> DEC3
    DEC3 --> DEC4
    DEC4 --> DEC5
    DEC5 --> RTE
    RTE --> RTE5
```

## Confidence Flow and Routing Logic

```mermaid
flowchart TD
    START([PA Request]) --> ING[Ingestion Zone]
    ING --> EXT[Extraction Zone]
    EXT --> |"extraction_confidence"| EXT_GATE{Extraction<br/>Quality ≥ 0.80?}
    
    EXT_GATE -->|No| HUMAN_EXT[Human Extraction Review]
    HUMAN_EXT --> DEC[Decision Zone]
    EXT_GATE -->|Yes| DEC
    
    DEC --> CRITIC[Critic Agent]
    CRITIC --> HALL{Hallucinations<br/>Detected?}
    
    HALL -->|Yes| HUMAN_DEC[Human Decision Review]
    HALL -->|No| CONF{Decision<br/>Confidence?}
    
    CONF -->|"≥ 0.95"| AUTO[Auto-Approval<br/>RTE-1]
    CONF -->|"0.80-0.95"| NURSE[Nurse Review<br/>RTE-2]
    CONF -->|"0.60-0.80"| MD[MD Review<br/>RTE-3]
    CONF -->|"< 0.60"| HUMAN_DEC
    
    CRITIC --> DENY{Denial with<br/>conf ≥ 0.90?}
    DENY -->|Yes| DENIAL[Denial Prep<br/>RTE-4]
    
    AUTO & NURSE & MD & DENIAL & HUMAN_DEC --> RESPONSE[Response Generator<br/>RTE-5]
    RESPONSE --> END([Final Output])

    style AUTO fill:#28a745,stroke:#1e7e34,color:#fff
    style NURSE fill:#ffc107,stroke:#d39e00,color:#000
    style MD fill:#fd7e14,stroke:#dc6502,color:#fff
    style DENIAL fill:#dc3545,stroke:#bd2130,color:#fff
    style HUMAN_DEC fill:#6c757d,stroke:#545b62,color:#fff
    style HUMAN_EXT fill:#6c757d,stroke:#545b62,color:#fff
```

## Agent Communication Protocol

```mermaid
sequenceDiagram
    participant ORC as Orchestrator
    participant ING as Ingestion Agents
    participant EXT as Extraction Agents
    participant DEC as Decision Agents
    participant QA as QA Agents
    participant RTE as Routing Agents

    Note over ORC: PA Request Received
    
    ORC->>+ING: Launch ING-1,2,3,4 (parallel)
    ING-->>-ORC: Ingestion complete
    
    ORC->>+EXT: Launch EXT-P1, EXT-C1-4 (parallel)
    ORC->>+QA: Start QA-1 monitoring
    
    EXT-->>ORC: Extraction outputs
    ORC->>EXT: Launch EXT-V1 (validation)
    EXT-->>-ORC: Validated extractions
    
    QA-->>ORC: Quality metrics (continuous)
    
    ORC->>+DEC: Launch DEC-1, DEC-2 (parallel)
    DEC-->>ORC: Criteria + Necessity
    ORC->>DEC: Launch DEC-3 (gaps)
    DEC-->>ORC: Gap analysis
    ORC->>DEC: Launch DEC-4 (decision)
    DEC-->>ORC: Decision output
    ORC->>DEC: Launch DEC-5 (critic)
    DEC-->>-ORC: Critic assessment
    
    ORC->>+QA: Final compliance check
    QA-->>-ORC: Compliance status
    
    alt High Confidence (≥0.95)
        ORC->>+RTE: Launch RTE-1 (auto-approve)
    else Medium Confidence (0.80-0.95)
        ORC->>+RTE: Launch RTE-2 (nurse queue)
    else Low Confidence (<0.80)
        ORC->>+RTE: Launch RTE-3 (MD escalation)
    end
    
    RTE-->>ORC: Routing complete
    ORC->>RTE: Launch RTE-5 (response)
    RTE-->>-ORC: Final output
    
    Note over ORC: PA Processing Complete
```

## Error Handling Flow

```mermaid
flowchart TD
    subgraph ERROR_TYPES["Error Classification"]
        TIMEOUT[Agent Timeout]
        DATA_ERR[Data Quality Error]
        SYS_ERR[System Error]
        QUALITY_FAIL[Quality Gate Failure]
    end

    TIMEOUT --> RETRY1{Retry Count<br/>< 3?}
    RETRY1 -->|Yes| RETRY_EXT[Retry with<br/>Extended Timeout]
    RETRY1 -->|No| ESCALATE[Escalate to<br/>Human Processing]

    DATA_ERR --> PARTIAL{Partial<br/>Processing<br/>Possible?}
    PARTIAL -->|Yes| DEGRADE[Continue with<br/>Degraded Confidence]
    PARTIAL -->|No| REQUEST_INFO[Request<br/>Additional Data]

    SYS_ERR --> ALERT[Alert Operations]
    ALERT --> QUEUE[Queue for<br/>Manual Processing]

    QUALITY_FAIL --> REMEDIATE{Remediation<br/>Possible?}
    REMEDIATE -->|Yes| ALT_PROMPT[Re-run with<br/>Alternative Prompts]
    REMEDIATE -->|No| HUMAN_REV[Human Review<br/>with Context]

    RETRY_EXT --> SUCCESS{Success?}
    SUCCESS -->|Yes| CONTINUE[Continue<br/>Pipeline]
    SUCCESS -->|No| ESCALATE

    DEGRADE --> CONTINUE
    REQUEST_INFO --> PEND[Pend Case]
    ALT_PROMPT --> CONTINUE

    style ESCALATE fill:#dc3545,color:#fff
    style HUMAN_REV fill:#dc3545,color:#fff
    style QUEUE fill:#dc3545,color:#fff
    style CONTINUE fill:#28a745,color:#fff
    style PEND fill:#ffc107,color:#000
```

## Parallel Execution Timeline

```mermaid
gantt
    title PA Processing Timeline (Target: <5 minutes)
    dateFormat X
    axisFormat %S

    section Zone 1: Ingestion
    ING-1 Document Validation    :ing1, 0, 30s
    ING-2 OCR Processing         :ing2, 0, 120s
    ING-3 Classification         :ing3, 0, 15s
    ING-4 Request Routing        :ing4, 0, 10s

    section Zone 2: Extraction
    EXT-P1 Policy Archivist      :extp1, after ing2, 45s
    EXT-C1 Diagnosis Extractor   :extc1, after ing2, 60s
    EXT-C2 Treatment History     :extc2, after ing2, 90s
    EXT-C3 Diagnostic Results    :extc3, after ing2, 90s
    EXT-C4 Timeline Constructor  :extc4, after extc3, 60s
    EXT-V1 Extraction Validator  :extv1, after extc4, 45s

    section Zone 3: Decision
    DEC-1 Criteria Matcher       :dec1, after extv1, 90s
    DEC-2 Medical Necessity      :dec2, after extv1, 90s
    DEC-3 Gap Analyzer           :dec3, after dec2, 60s
    DEC-4 Decision Engine        :dec4, after dec3, 120s
    DEC-5 Critic Agent           :dec5, after dec4, 90s

    section Zone 4: Routing
    RTE-X Routing Decision       :rte, after dec5, 60s
    RTE-5 Response Generator     :rte5, after rte, 30s

    section QA (Continuous)
    QA-1 Hallucination Monitor   :qa1, after ing2, 420s
    QA-3 Compliance Check        :qa3, after dec5, 30s
```
