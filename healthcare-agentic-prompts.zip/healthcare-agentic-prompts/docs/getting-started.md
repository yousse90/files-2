# Getting Started

This guide will help you understand and use the healthcare agentic prompts in this repository.

## Prerequisites

- Basic understanding of LLM prompting
- Familiarity with healthcare/prior authorization workflows (helpful but not required)
- Access to an LLM API (Claude, GPT-4, etc.)

## Understanding the Architecture

### The Multi-Agent Pattern

Healthcare prior authorization is complex. Rather than trying to build one monolithic prompt that handles everything, we use a **multi-agent orchestration pattern**:

```
┌─────────────────────────────────────────────────────────────┐
│                     ORCHESTRATOR                            │
│  • Coordinates agents                                       │
│  • Manages dependencies                                     │
│  • Enforces quality gates                                   │
│  • Routes based on confidence                               │
└─────────────────────────────────────────────────────────────┘
                           │
         ┌─────────────────┼─────────────────┐
         ▼                 ▼                 ▼
   ┌───────────┐    ┌───────────┐    ┌───────────┐
   │ Extraction│    │ Decision  │    │  Quality  │
   │  Agents   │    │  Agents   │    │  Agents   │
   └───────────┘    └───────────┘    └───────────┘
```

### Why Multi-Agent?

1. **Specialization**: Each agent focuses on one task and does it well
2. **Parallelization**: Independent agents can run concurrently
3. **Quality Control**: Dedicated QA agents catch errors
4. **Transparency**: Clear audit trail through the pipeline
5. **Maintainability**: Update individual agents without rebuilding everything

## Quick Start Options

### Option 1: Use Individual Agents

Start with a single agent to understand the pattern:

```python
import anthropic

# Load the Policy Archivist prompt
with open("agents/extraction/policy-archivist.md") as f:
    prompt_content = f.read()

# Extract just the role and rules sections for the system prompt
# (In production, you'd parse this more carefully)
system_prompt = """
You are a specialized healthcare AI agent responsible for extracting medical 
necessity criteria from insurance policy documents. Your outputs directly 
impact prior authorization decisions affecting patient care.

Critical Safety Rules:
- NEVER fabricate policy criteria not present in the source document
- ALWAYS cite specific policy sections for each extracted criterion
- ALWAYS preserve exact threshold values
- Flag any ambiguous policy language rather than interpreting it
"""

client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=4096,
    system=system_prompt,
    messages=[{
        "role": "user",
        "content": f"""
        Extract all medical necessity criteria from this policy:
        
        [Your policy text here]
        
        Return as structured JSON matching this schema:
        {{
          "policy_id": "string",
          "criteria": [{{
            "criterion_id": "string",
            "description": "string",
            "required": boolean,
            "threshold": "string",
            "source_section": "string"
          }}]
        }}
        """
    }]
)

print(response.content[0].text)
```

### Option 2: Build a Simple Pipeline

Connect two agents in sequence:

```python
import anthropic
import json

client = anthropic.Anthropic()

def run_agent(system_prompt: str, user_message: str) -> dict:
    """Run a single agent and return parsed JSON output."""
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}]
    )
    return json.loads(response.content[0].text)

# Step 1: Extract policy criteria
policy_criteria = run_agent(
    system_prompt=POLICY_ARCHIVIST_PROMPT,
    user_message=f"Extract criteria from: {policy_text}"
)

# Step 2: Match clinical evidence to criteria
criteria_match = run_agent(
    system_prompt=CRITERIA_MATCHER_PROMPT,
    user_message=f"""
    Policy Criteria: {json.dumps(policy_criteria)}
    Clinical Evidence: {clinical_notes}
    
    Evaluate each criterion as Met/Not Met/Insufficient.
    """
)

print(json.dumps(criteria_match, indent=2))
```

### Option 3: Full Orchestrated Pipeline

For production use, implement the full orchestrator pattern. See the [Architecture Guide](architecture.md) for details.

## Key Concepts

### 1. Confidence Scoring

Every agent outputs a confidence score (0.0 - 1.0):

```json
{
  "output": "...",
  "confidence": 0.87,
  "confidence_factors": {
    "source_quality": 0.95,
    "extraction_completeness": 0.82,
    "ambiguity_level": 0.85
  }
}
```

Confidence determines routing:
- **≥ 0.95**: Eligible for auto-processing
- **0.80 - 0.95**: Requires nurse review
- **< 0.80**: Requires physician review

### 2. Source Citations

All clinical claims MUST cite sources:

```json
{
  "claim": "Patient has K-L Grade 4 osteoarthritis",
  "source_document": "MRI_Report_20240115.pdf",
  "page_reference": "Page 2",
  "verbatim_quote": "Findings consistent with K-L Grade 4"
}
```

### 3. Hallucination Prevention

The Critic Agent verifies all claims:

```python
for claim in decision_output.claims:
    verification = verify_against_source(
        claim=claim,
        source_documents=source_documents
    )
    
    if verification.status == "UNVERIFIED":
        block_auto_processing()
        escalate_to_human_review()
```

### 4. Quality Gates

Each zone has quality thresholds:

| Zone | Gate | Threshold | Action if Failed |
|------|------|-----------|------------------|
| Extraction | Completeness | ≥ 0.80 | Human extraction review |
| Decision | Accuracy | ≥ 0.85 | Require revision |
| Critic | No Hallucinations | 100% | Block auto-processing |

## Common Patterns

### Pattern 1: Parallel Extraction

Run multiple extractors concurrently:

```python
import asyncio

async def parallel_extraction(documents):
    tasks = [
        extract_diagnoses(documents),
        extract_treatments(documents),
        extract_diagnostics(documents),
        extract_from_policy(policy_doc)
    ]
    
    results = await asyncio.gather(*tasks)
    
    return {
        "diagnoses": results[0],
        "treatments": results[1],
        "diagnostics": results[2],
        "policy_criteria": results[3]
    }
```

### Pattern 2: Confidence Cascading

Propagate minimum confidence through pipeline:

```python
def calculate_final_confidence(agent_outputs: list) -> float:
    """Final confidence is limited by weakest link."""
    confidences = [output.confidence for output in agent_outputs]
    return min(confidences)
```

### Pattern 3: Critic Validation

Always run critic before final output:

```python
def finalize_decision(decision_output, source_documents):
    critic_result = run_critic_agent(
        decision=decision_output,
        sources=source_documents
    )
    
    if critic_result.hallucinations_detected:
        raise HallucinationError("Cannot auto-process")
    
    if critic_result.overall_validity == "invalid":
        return route_to_human_review(decision_output, critic_result)
    
    return decision_output
```

## Testing Your Implementation

### Unit Testing Agents

```python
def test_policy_extraction():
    """Test that policy archivist extracts all criteria."""
    test_policy = load_test_case("test-cases/policy-extraction-001.json")
    
    result = run_policy_archivist(test_policy["input"])
    
    assert len(result["criteria"]) == test_policy["expected"]["criteria_count"]
    assert result["confidence"] >= 0.80
    
    for criterion in result["criteria"]:
        assert "source_section" in criterion
        assert "verbatim_quote" in criterion
```

### Integration Testing

```python
def test_full_pipeline():
    """Test end-to-end PA processing."""
    test_case = load_test_case("test-cases/integration-001.json")
    
    result = run_full_pipeline(
        policy=test_case["policy"],
        clinical_docs=test_case["clinical_documents"]
    )
    
    assert result["decision"] == test_case["expected_decision"]
    assert result["critic_assessment"]["hallucinations_detected"] == False
```

## Next Steps

1. **Explore individual agents**: Start with [Policy Archivist](../agents/extraction/policy-archivist.md)
2. **Understand safety patterns**: Read [Safety Guidelines](safety-guidelines.md)
3. **See full architecture**: Review [Architecture Guide](architecture.md)
4. **Try examples**: Work through [Prior Auth Example](../examples/prior-auth-case/)

## Getting Help

- **Questions**: Open a [Discussion](https://github.com/YOUR_USERNAME/healthcare-agentic-prompts/discussions)
- **Bugs**: Open an [Issue](https://github.com/YOUR_USERNAME/healthcare-agentic-prompts/issues)
- **Contributing**: See [CONTRIBUTING.md](../CONTRIBUTING.md)

---

**Remember**: These prompts are for research and education. Always validate thoroughly before any clinical deployment.
